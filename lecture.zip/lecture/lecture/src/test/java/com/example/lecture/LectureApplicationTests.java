package com.example.lecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
