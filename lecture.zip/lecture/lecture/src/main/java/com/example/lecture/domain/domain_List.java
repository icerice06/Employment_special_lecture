package com.example.lecture.domain;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "list")
public class domain_List {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long detailedCode;
    private String password;
    private String title;
    private String writer;
    private String content;
    private Long categoryCode;
    private LocalDateTime createdAt;
}
