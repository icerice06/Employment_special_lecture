package com.example.lecture.service;

import com.example.lecture.domain.Category;
import com.example.lecture.domain.domain_List;
import com.example.lecture.repository.CategoryRepository;
import com.example.lecture.repository.ListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BoardService {

    @Autowired
    private CategoryRepository categoryRepository;

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Autowired
    private ListRepository listRepository;

    public List<domain_List> getAllList() {
        return listRepository.findAll();
    }

}
