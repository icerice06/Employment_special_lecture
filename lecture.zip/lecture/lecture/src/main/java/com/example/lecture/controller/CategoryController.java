package com.example.lecture.controller;

import com.example.lecture.domain.Category;
import com.example.lecture.domain.domain_List;
import com.example.lecture.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
public class CategoryController {

    @Autowired
    private BoardService BoardService;

    @GetMapping("/category")
    public List<Category> getAllCategories() {
        return BoardService.getAllCategories();
    }



    @GetMapping("/list")
    public List<domain_List> listRepository(@RequestParam(value = "code") Long code) {
        List<domain_List> allList = BoardService.getAllList();

        List<domain_List> filteredList = allList.stream()
                .filter(item -> Objects.equals(item.getCategoryCode(), code))
                .collect(Collectors.toList());
        return filteredList;
    }
}
