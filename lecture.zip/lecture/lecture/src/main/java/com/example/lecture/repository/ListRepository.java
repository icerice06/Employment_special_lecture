package com.example.lecture.repository;

import com.example.lecture.domain.domain_List;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ListRepository extends JpaRepository<domain_List, Long> {
}