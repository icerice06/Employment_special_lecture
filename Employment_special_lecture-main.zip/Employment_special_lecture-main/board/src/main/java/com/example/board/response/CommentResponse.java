package com.example.board.response;

import com.example.board.DTO.CommentDTO;
import com.example.board.entity.CommentEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class CommentResponse {
}
